var modules =
[
    [ "DEBUG", "group__debug.html", null ],
    [ "Global Variables", "group__global_vars.html", "group__global_vars" ],
    [ "Interface to the C part of LAPACK", "group__lapack.html", "group__lapack" ],
    [ "Auxiliary classes", "group__class.html", "group__class" ],
    [ "Global Functions", "group__global_fun.html", "group__global_fun" ]
];