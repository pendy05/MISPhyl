var structprotein__degree =
[
    [ "operator()", "structprotein__degree.html#af41c3a69333081d2489e86f8c75c5cf1", null ]
];