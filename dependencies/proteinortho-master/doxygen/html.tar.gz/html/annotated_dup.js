var annotated_dup =
[
    [ "compare_ConnectedComponents", "structcompare___connected_components.html", "structcompare___connected_components" ],
    [ "ConnectedComponent", "class_connected_component.html", "class_connected_component" ],
    [ "protein", "structprotein.html", "structprotein" ],
    [ "protein_degree", "structprotein__degree.html", "structprotein__degree" ],
    [ "wedge", "structwedge.html", "structwedge" ]
];