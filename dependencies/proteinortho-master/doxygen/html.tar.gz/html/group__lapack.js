var group__lapack =
[
    [ "dssyevr_", "group__lapack.html#gacbd94c82f0b328d08becb1aceebb74a9", null ],
    [ "dsyevr_", "group__lapack.html#ga7091dd563efd31383bb6f99d83e7a2ab", null ],
    [ "ssyevr_", "group__lapack.html#ga3333c64828ea0a66a39b383c29440ba4", null ]
];