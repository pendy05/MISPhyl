var searchData=
[
  ['test_5f_5fgenerate_5frandom_5fvector_85',['test__generate_random_vector',['../group__global_fun.html#gad79c002a388ee3d69f4baffb05007ddb',1,'proteinortho_clustering.h']]],
  ['test_5f_5fget_5fnew_5fx_86',['test__get_new_x',['../group__global_fun.html#ga92b261b4beacb10b079413fc1ab00c73',1,'proteinortho_clustering.h']]],
  ['test_5f_5fgety_87',['test__getY',['../group__global_fun.html#gad6f0ea250692e023380c88a84a2b5e2b',1,'proteinortho_clustering.h']]],
  ['test_5f_5fmakeorthogonal_88',['test__makeOrthogonal',['../group__global_fun.html#ga854ca6e1f5cc459bbb76f112b3601c80',1,'proteinortho_clustering.h']]],
  ['test_5f_5fmax_5fof_5fdiag_89',['test__max_of_diag',['../group__global_fun.html#ga1de5dfc864ba9528514051adb36f1dc8',1,'proteinortho_clustering.h']]],
  ['test_5f_5fnormalize_90',['test__normalize',['../group__global_fun.html#gafc5c485f124401768ff910a218a1b2e6',1,'proteinortho_clustering.h']]],
  ['test_5f_5fsplitgroups_91',['test__splitGroups',['../group__global_fun.html#ga26e50964c0cdbcbfb49be46db1274668',1,'proteinortho_clustering.h']]],
  ['tokenize_92',['tokenize',['../group__global_fun.html#ga0383fbb9bd0cfab94b3989dc70b1a201',1,'proteinortho_clustering.h']]]
];
