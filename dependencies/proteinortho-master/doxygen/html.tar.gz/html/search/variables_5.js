var searchData=
[
  ['kmereheuristic_5fminnodes_156',['kmereHeuristic_minNodes',['../group__global_vars.html#ga2ca2803d4a312bc9556156898e9c1b4a',1,'proteinortho_clustering.h']]],
  ['kmereheuristic_5fminnumberofgroups_157',['kmereHeuristic_minNumberOfGroups',['../group__global_vars.html#ga2b9d4c984f0557340774a4c61aaa0fbe',1,'proteinortho_clustering.h']]],
  ['kmereheuristic_5fprotperspecies_158',['kmereHeuristic_protPerSpecies',['../group__global_vars.html#ga71b56ed02b5af410ba5d4e4ca0230cc2',1,'proteinortho_clustering.h']]]
];
