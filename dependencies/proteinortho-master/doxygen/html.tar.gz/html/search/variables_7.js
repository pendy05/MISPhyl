var searchData=
[
  ['m_5fcontent_5fcc_160',['m_content_CC',['../class_connected_component.html#aa73b6fe2810e400f0e4217566ead3aaf',1,'ConnectedComponent']]],
  ['maxuseweightsnumnodes_161',['maxUseWeightsNumNodes',['../group__global_vars.html#ga0b81992a506f43a8f1ee715613d9dff3',1,'proteinortho_clustering.h']]],
  ['min_5fiter_162',['min_iter',['../group__global_vars.html#ga85329c021e097be8080f9ec86df1ba53',1,'proteinortho_clustering.h']]]
];
