var searchData=
[
  ['protein_97',['protein',['../structprotein.html',1,'']]],
  ['protein_5fdegree_98',['protein_degree',['../structprotein__degree.html',1,'']]]
];
