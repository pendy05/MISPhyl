var searchData=
[
  ['floatprecision_5fh_18',['floatprecision_H',['../proteinortho__clustering_8h.html#a6f8a2832263057edb6ca056e20007a67',1,'proteinortho_clustering.h']]],
  ['floattype_19',['floattype',['../proteinortho__clustering_8h.html#a4adfc1f90179e7690059be8ac0c50b00',1,'proteinortho_clustering.h']]],
  ['full_5fname_20',['full_name',['../structprotein.html#a0434c661e2750a20f39afc75121bd438',1,'protein']]]
];
