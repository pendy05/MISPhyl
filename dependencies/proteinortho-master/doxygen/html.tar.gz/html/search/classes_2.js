var searchData=
[
  ['wedge_99',['wedge',['../structwedge.html',1,'']]]
];
