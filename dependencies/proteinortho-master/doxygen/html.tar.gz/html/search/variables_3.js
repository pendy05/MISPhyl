var searchData=
[
  ['full_5fname_152',['full_name',['../structprotein.html#a0434c661e2750a20f39afc75121bd438',1,'protein']]]
];
