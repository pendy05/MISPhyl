var searchData=
[
  ['dssyevr_5f_108',['dssyevr_',['../group__lapack.html#gacbd94c82f0b328d08becb1aceebb74a9',1,'proteinortho_clustering.h']]],
  ['dsyevr_5f_109',['dsyevr_',['../group__lapack.html#ga7091dd563efd31383bb6f99d83e7a2ab',1,'proteinortho_clustering.h']]]
];
