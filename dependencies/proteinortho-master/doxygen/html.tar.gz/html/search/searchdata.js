var indexSectionsWithContent =
{
  0: "abcdefgiklmnoprstw",
  1: "cpw",
  2: "p",
  3: "bcdgmnoprst",
  4: "cdefgklmnprsw",
  5: "f",
  6: "f",
  7: "adgi"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros",
  7: "Modules"
};

