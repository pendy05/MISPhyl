var searchData=
[
  ['floattype_184',['floattype',['../proteinortho__clustering_8h.html#a4adfc1f90179e7690059be8ac0c50b00',1,'proteinortho_clustering.h']]]
];
