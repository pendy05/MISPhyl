var searchData=
[
  ['species_180',['species',['../group__global_vars.html#gae8aa46c9b0522c51c6a5bb96910c2f6c',1,'proteinortho_clustering.h']]],
  ['species_5fcounter_181',['species_counter',['../group__global_vars.html#ga6b9d6440326361b3208bf0211d0e518e',1,'proteinortho_clustering.h']]],
  ['species_5fid_182',['species_id',['../structprotein.html#a431e29584b29b6cd9f9b20f41ba65d4b',1,'protein']]]
];
