var searchData=
[
  ['critical_5fmin_5fnodes_146',['critical_min_nodes',['../group__global_vars.html#ga9855fd092f1bf46c607f61fca2135c14',1,'proteinortho_clustering.h']]]
];
