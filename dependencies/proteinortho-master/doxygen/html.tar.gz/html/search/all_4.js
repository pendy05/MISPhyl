var searchData=
[
  ['edge_16',['edge',['../structwedge.html#a2aeda1cf956ff2e2c2d3b8ea5f5c95c9',1,'wedge']]],
  ['edges_17',['edges',['../structprotein.html#a357e01b2c8a47d83e4bbbe7acb28d402',1,'protein::edges()'],['../group__global_vars.html#ga3909ec6969640783bef950d73a185847',1,'edges():&#160;proteinortho_clustering.h']]]
];
