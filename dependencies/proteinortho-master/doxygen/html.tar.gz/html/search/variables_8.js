var searchData=
[
  ['num_5fcpus_163',['num_cpus',['../group__global_vars.html#ga7544268fce43a4619eba0a4307645183',1,'proteinortho_clustering.h']]]
];
