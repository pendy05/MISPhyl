var searchData=
[
  ['size_131',['size',['../class_connected_component.html#ae6b96aaade3047168a93cd1e228022c7',1,'ConnectedComponent::size()'],['../class_connected_component.html#a39742093ab53cae045f99f904b66e55c',1,'ConnectedComponent::size() const']]],
  ['sort_5fspecies_132',['sort_species',['../group__global_fun.html#ga2623f67f602e8edf6ba80dea1b5241d0',1,'proteinortho_clustering.h']]],
  ['splitgroups_133',['splitGroups',['../group__global_fun.html#ga833c1999fcb7286c4242fe2ff54b0cd7',1,'proteinortho_clustering.h']]],
  ['ssyevr_5f_134',['ssyevr_',['../group__lapack.html#ga3333c64828ea0a66a39b383c29440ba4',1,'proteinortho_clustering.h']]],
  ['stats_135',['stats',['../group__global_fun.html#gaa37ee1041366dd1c1432e7b9f8ac2349',1,'proteinortho_clustering.h']]],
  ['string2floattype_136',['string2floattype',['../group__global_fun.html#ga14d39a4e40fe7b1df4f576edbac1ab4b',1,'proteinortho_clustering.h']]],
  ['sumoutdegs_137',['sumOutDegs',['../group__global_fun.html#ga7727f35f236c1b6e4c9996b2611ba373',1,'proteinortho_clustering.h']]]
];
