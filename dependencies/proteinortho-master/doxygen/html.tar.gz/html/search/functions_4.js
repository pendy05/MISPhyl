var searchData=
[
  ['makeorthogonal_116',['makeOrthogonal',['../group__global_fun.html#ga9d67a0bb96e05e51358dcd0aa07f074b',1,'proteinortho_clustering.h']]],
  ['max_5fof_5fdiag_117',['max_of_diag',['../group__global_fun.html#ga78ea557649a4b6b66f9026468b13d4c8',1,'proteinortho_clustering.h']]]
];
