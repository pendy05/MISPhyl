var searchData=
[
  ['remove_5fedge_5findex_72',['remove_edge_index',['../group__global_fun.html#gad7f220abb1202e298d241614d937c6f6',1,'proteinortho_clustering.h']]],
  ['removeexternaledges_73',['removeExternalEdges',['../group__global_fun.html#ga76f1cfd6740d2e99e41d7ae0827c5b62',1,'proteinortho_clustering.h']]],
  ['reorder_5ftable_74',['reorder_table',['../group__global_vars.html#gac81614e69c191302561db5e2e281aba7',1,'proteinortho_clustering.h']]]
];
