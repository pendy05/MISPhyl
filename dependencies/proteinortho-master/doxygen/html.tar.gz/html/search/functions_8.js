var searchData=
[
  ['remove_5fedge_5findex_129',['remove_edge_index',['../group__global_fun.html#gad7f220abb1202e298d241614d937c6f6',1,'proteinortho_clustering.h']]],
  ['removeexternaledges_130',['removeExternalEdges',['../group__global_fun.html#ga76f1cfd6740d2e99e41d7ae0827c5b62',1,'proteinortho_clustering.h']]]
];
