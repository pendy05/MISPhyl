var searchData=
[
  ['global_20functions_188',['Global Functions',['../group__global_fun.html',1,'']]],
  ['global_20variables_189',['Global Variables',['../group__global_vars.html',1,'']]]
];
