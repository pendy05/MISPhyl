var structwedge =
[
    [ "edge", "structwedge.html#a2aeda1cf956ff2e2c2d3b8ea5f5c95c9", null ],
    [ "weight", "structwedge.html#aa672cd5baacbb342e54c84649decd3dc", null ]
];