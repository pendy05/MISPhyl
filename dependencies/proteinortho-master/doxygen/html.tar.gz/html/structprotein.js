var structprotein =
[
    [ "edges", "structprotein.html#a357e01b2c8a47d83e4bbbe7acb28d402", null ],
    [ "full_name", "structprotein.html#a0434c661e2750a20f39afc75121bd438", null ],
    [ "species_id", "structprotein.html#a431e29584b29b6cd9f9b20f41ba65d4b", null ]
];